#!/usr/bin/env bash
# autor: HenriqueAD <www.osistematico.com.br>
# descrição: O que seu Script/Programa faz 
# version: 1.0
# licença: MIT License




exit
